return {
	WrapInFunction       = require("prometheus.steps.WrapInFunction");
	ConstantArray        = require("prometheus.steps.ConstantArray");
	ProxifyLocals  			 = require("prometheus.steps.ProxifyLocals");
	AntiTamper  				 = require("prometheus.steps.AntiTamper");
}